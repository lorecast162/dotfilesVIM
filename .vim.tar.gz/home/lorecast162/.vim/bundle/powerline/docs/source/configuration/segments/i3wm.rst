*************
i3wm segments
*************

.. automodule:: powerline.segments.i3wm
   :members:
