:orphan:

powerline manual page
=====================

.. automan:: powerline.commands.main
   :prog: powerline

See also
--------

:manpage:`powerline-daemon(1)`, :manpage:`powerline-config(1)`
